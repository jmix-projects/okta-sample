package com.company.oks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OktaSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
